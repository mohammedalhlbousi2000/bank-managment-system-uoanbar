from tkinter import *
import tkinter as tk 
import os
from PIL import ImageTk, Image


begin = Tk()
begin.geometry('350x200')

begin.title("Banking App")

# main screen
master = Toplevel(begin)
master.title("Banking App")
#Functions
def finish_reg():
    name = temp_name.get()
    age = temp_age.get()
    address = temp_address.get()
    number = temp_number.get()
    country = temp_country_name.get()
    job = temp_job_name.get()
    gender = temp_gender.get()
    password = temp_password.get()

    all_accounts = os.listdir()
    print(all_accounts)

    if name  == "" or age == "" or gender == "" or password == "":
        notif.config(fg="red",text="All feilds required + ")
        return
    for name_check in all_accounts:
        if name == name_check:
            notif.config(fg="red",text="Account already exists")
            return
        else:
            new_file = open(name,"w")
            new_file.write(name+'\n')
            new_file.write(age+'\n')
            new_file.write(address+'\n')
            new_file.write(number+'\n')
            new_file.write(country+'\n')
            new_file.write(job+'\n')
            new_file.write(gender+'\n')
            new_file.write(password+'\n')
            new_file.close()


            notif.config(fg="green" , text="Account has been created")
    
def register():
    #vars
    global temp_name
    global temp_age
    global temp_address
    global temp_number
    global temp_country_name
    global temp_job_name
    global temp_gender
    global temp_password
    global notif
    temp_name = StringVar()
    temp_age = StringVar()
    temp_address = StringVar()
    temp_number = StringVar()
    temp_country_name = StringVar()
    temp_job_name = StringVar()
    temp_gender = StringVar()
    temp_password = StringVar()
    
    #register screen
    register_screen = Toplevel(begin)
    register_screen.title('Register')
    
    #lables
    Label(register_screen, text="please enter your details below to register",font=('calibri',12)).grid(row=0,sticky=N,pady=10)
    Label(register_screen, text="Name",font=('Calibri',12)).grid(row=1,sticky=W)
    Label(register_screen, text="Age",font=('Calibri',12)).grid(row=2,sticky=W)
    Label(register_screen, text="Address",font=('Calibri',12)).grid(row=3,sticky=W)
    Label(register_screen, text="Number",font=('Calibri',12)).grid(row=4,sticky=W)
    Label(register_screen, text="Country",font=('Calibri',12)).grid(row=5,sticky=W)
    Label(register_screen, text="Job",font=('Calibri',12)).grid(row=6,sticky=W)
    Label(register_screen, text="Gender",font=('Calibri',12)).grid(row=7,sticky=W)
    Label(register_screen, text="Password",font=('Calibri',12)).grid(row=8,sticky=W)
    notif=Label(register_screen, font=('Calibri',12))
    notif.grid(row=9,sticky=N,pady=10)
    
    #Enteries
    Entry(register_screen,textvariable=temp_name).grid(row=1,column=0)
    Entry(register_screen,textvariable=temp_age).grid(row=2,column=0)
    Entry(register_screen,textvariable=temp_address).grid(row=3,column=0)
    Entry(register_screen,textvariable=temp_number).grid(row=4,column=0)
    Entry(register_screen,textvariable=temp_country_name).grid(row=5,column=0)
    Entry(register_screen,textvariable=temp_job_name).grid(row=6,column=0)
    Entry(register_screen,textvariable=temp_gender).grid(row=7,column=0)
    Entry(register_screen,textvariable=temp_password,show="*").grid(row=8,column=0)
    

    #Buttons
    Button(register_screen, text="register" , command=finish_reg, font=('Calibri',12)).grid(row=9,sticky=N,pady=10)
    
def login_session():
    global login_name
    all_accounts = os.listdir()
    login_name = temp_login_name.get()
    login_password = temp_login_password.get()

    for name in all_accounts:
        if name == login_name:
            file = open(name,"r")
            file_data = file.read()
            file_data = file_data.split("\n")
            password = file_data[1]
            #Account Dashboard
            if login_password == password:
                login_screen.destroy()
                account_dashboard = Toplevel(begin)
                account_dashboard.title("Dashboard")
                #Label
                Label(account_dashboard,text="Account Dashboard",font=("Calibri",12)).grid(row=0,sticky=W,pady=10)
                Label(account_dashboard,text="Welcome " + name,font=("Calibri",12)).grid(row=1,sticky=W,pady=5)
                
                #Button(this is you can add another button like account statement and other keys)####################################################


                
                Button(account_dashboard, text="Accauont Statement",font=("Calibri",12),width=30,command=personal_details).grid(row=2,sticky=N,padx=5)
                Button(account_dashboard, text="Text Message",font=("Calibri",12),width=30,command=text_message).grid(row=3,sticky=N,padx=5)
                Button(account_dashboard, text="Deposit",font=("Calibri",12),width=30,command=deposit).grid(row=4,sticky=N,padx=10)
                Button(account_dashboard, text="Currency Convert",font=("Calibri",12),width=30, command=currancy_screen).grid(row=5,sticky=N,padx=100)
                Button(account_dashboard, text="withdrawal",font=("Calibri",12),width=30,command=withdraw).grid(row=6,sticky=N,padx=10)
                Button(account_dashboard, text="Email Sender" , command=email_sender, font=('Calibri',12),width=30).grid(row=7,sticky=N,padx=5)
                Button(account_dashboard, text="account statement",font=("Calibri",12),width=30).grid(row=8,sticky=N,padx=100)
                Label(account_dashboard).grid(row=5,sticky=N,pady=10)
                
                return
            else:
                login_notif.config(fg="red",text = "Password incorrect")
                return
                login_notif.config(fg="red" , text = "No account found !!! ")


#them change_______________________________________________________>>>>>>>
def change_theme():
   current_bg = master.cget("bg")
   new_bg = "white" if current_bg == "black" else "black"
   master.configure(bg=new_bg)


def deposit():
    #Vars
    global amount
    global deposit_notif
    global current_balance_label
    amount = StringVar()
    file = open(login_name,"r")
    file_data = file.read()
    user_details = file_data.split('\n')
    details_balance = user_details[4]
    #Deposit Screen
    deposit_screen = Toplevel(begin)
    deposit_screen.title('Deposit')
    #Label
    Label(deposit_screen, text = "Deposit", font=("Calibri",12)).grid(row=0,sticky=N,pady=10)
    current_balance_label= Label(deposit_screen, text = "current Balance : G "+details_balance, font=("Calibri",12))
    current_balance_label.grid(row=1,sticky=W)
    Label(deposit_screen, text="Amount : ", font=("Calibri",12)).grid(row=2,sticky=W)
    deposit_notif = Label(deposit_screen,font=("Calibri",12))
    deposit_notif.grid(row=4, sticky=N,pady=5)
    #Entrys
    Entry(deposit_screen , textvariable=amount).grid(row=2,column=1)
    #Button
    Button(deposit_screen,text="finish",font=("Calibri",12),command=finish_deposit).grid(row=3,sticky=W,pady=5)
def finish_deposit():
    if amount.get()=="":
        deposit_notif.config(text="Amount is required")
        return
    if float(amount.get()) <=0:
        deposit_notif.config(text="Negative Currency is not accept",fg="red")
        return
    file = open(login_name, "r+")
    file_data = file.read()
    details= file_data.split('\n')
    current_balance =details[4]
    updated_balance = current_balance
    updated_balance = float(updated_balance) + float(amount.get())
    file_data = file_data.replace(current_balance, str(updated_balance))
    file.seek(0)
    file.truncate(0)
    file.write(file_data)
    file.close()

    current_balance_label.config(text="Current Balance : G "+str(updated_balance), fg="green")
    deposit_notif.config(text="Balance update", fg="green")

                       
def withdraw():
 #Vars
    global withdraw_amount
    global withdraw_notif
    global current_balance_label
    withdraw_amount = StringVar()
    file = open(login_name, "r")
    file_data = file.read()
    user_details = file_data.split('\n')
    details_balance = user_details[4]
    #Deposit Screena
    withdraw_screen = Toplevel(begin)
    withdraw_screen.title('Deposit')
    #Label
    Label(withdraw_screen, text = "Withdraw", font=("Calibri",12)).grid(row=0,sticky=N,pady=10)
    current_balance_label= Label(withdraw_screen, text = "current Balance : G "+details_balance, font=("Calibri",12))
    current_balance_label.grid(row=1,sticky=W)
    Label(withdraw_screen, text="Amount : ", font=("Calibri",12)).grid(row=2,sticky=W)
    deposit_notif = Label(withdraw_screen,font=("Calibri",12))
    deposit_notif.grid(row=4, sticky=N,pady=5)
    #Entrys
    Entry(withdraw_screen , textvariable=withdraw_amount).grid(row=2,column=1)
    #Button
    Button(withdraw_screen,text="finish", font=("Calibri",12),command=finish_withdraw).grid(row=3,sticky=W,pady=5)

def finish_withdraw():
    if withdraw_amount.get()=="":
        withdraw_notif.config(text="Amount is required")
        return
    if float(withdraw_amount.get()) <=0:
        withdraw_notif.config(text="Negative Currency is not accept",fg="red")
        return
    file = open(login_name,"r+")
    file_data = file.read()
    details= file_data.split('\n')
    current_balance =details[4]
    if float (withdraw_amount.get()) > float(current_balance):
        withdraw_notif.config(text="Insufficent Funds!" , fg="red")
        return
    
    updated_balance = current_balance
    updated_balance = float(updated_balance) - float(amount.get())
    file_data = file_data.replace(current_balance,str(updated_balance))
    file.seek(0)
    file.truncate(0)
    file.write(file_data)
    file.close()

    current_balance_label.config(text="Current Balance : G "+str(updated_balance),fg="green")
    withdraw_notif.config(text="Balance update",fg="green")

#########################################################email_sender################################################
def email_sender():
    #vars
    global To
    global Subject
    global Message
    global temp_password
    To = StringVar()
    Subject = StringVar()
    Message = StringVar()
    
    
    #email_sender_creen
    email_sender_screen = Toplevel(begin)
    email_sender_screen.title('Email sender')
    
    #lables
    Label(email_sender_screen, text="Email sender to communcating with employee",font=('calibri',12)).grid(row=0,sticky=N,pady=10)
    Label(email_sender_screen, text="To",font=('Calibri',12)).grid(row=1,sticky=W)
    Label(email_sender_screen, text="Subject",font=('Calibri',12)).grid(row=2,sticky=W)
    Label(email_sender_screen, text="Message",font=('Calibri',12)).grid(row=3,sticky=W)
    
    #Enteries
    Entry(email_sender_screen,textvariable=To).grid(row=1,column=0)
    Entry(email_sender_screen,textvariable=Subject).grid(row=2,column=0)
    Entry(email_sender_screen,textvariable=Message).grid(row=3,column=0)
    

    #Buttons
    Button(email_sender_screen, text="Email_Sender" , command=email_sender, font=('Calibri',12)).grid(row=6,sticky=N,pady=10)
##############################################################################################################

def text_message():
    #vars
    global To
    global Subject
    global Message
    To = StringVar()
    Subject = StringVar()
    Message = StringVar()
    
    
    #email_sender_creen
    text_message_screen = Toplevel(begin)
    text_message_screen.title('Text Message')
    
    #lables
    Label(text_message_screen, text="Text message using phon number to communcating with employee",font=('calibri',12)).grid(row=0,sticky=N,pady=10)
    Label(text_message_screen, text="phone no",font=('Calibri',12)).grid(row=1,sticky=W)
    Label(text_message_screen, text="issues",font=('Calibri',12)).grid(row=2,sticky=W)
    Label(text_message_screen, text="notes",font=('Calibri',12)).grid(row=3,sticky=W)
    
    #Enteries
    Entry(text_message_screen,textvariable=To).grid(row=1,column=0)
    Entry(text_message_screen,textvariable=Subject).grid(row=2,column=0)
    Entry(text_message_screen,textvariable=Message).grid(row=3,column=0)
    

    #Buttons
    Button(text_message_screen, text="text_message" , command=text_message, font=('Calibri',12)).grid(row=6,sticky=N,pady=10)

    
    ############################################################################################################
def personal_details():
    #Var
    file = open(login_name,'r')
    file_data =file.read()
    user_details = file_data.split('\n')
    details_name = user_details[0]
    details_age = user_details[2]
    details_gender = user_details[3]
    details_balance = user_details[4]
    
    #personal details screen(we can do this as bank statement account)
    
    personal_details_screen = Toplevel(begin)
    personal_details_screen.title('personal Details')
    Label(personal_details_screen,text="personal details",font=('Calibri',12)).grid(row=0,sticky=N,pady=10)
    Label(personal_details_screen,text="Name "+details_name,font=('Calibri',12)).grid(row=1,sticky=W)
    Label(personal_details_screen,text="Age "+details_age,font=('Calibri',12)).grid(row=2,sticky=W)
    Label(personal_details_screen,text="Gender "+details_gender,font=('Calibri',12)).grid(row=3,sticky=W)
    Label(personal_details_screen,text="Balance "+details_balance,font=('Calibri',12)).grid(row=4,sticky=W)
        
def login():
    #Vars
    global temp_login_name
    global temp_login_password
    global temp_notif
    global login_screen
    temp_login_name = StringVar()
    temp_login_password = StringVar()
    #login screen
    login_screen = Toplevel(begin)
    login_screen.title("Login")
    #Labels
    Label(login_screen, text="login to your account", font=("calibri,12")).grid(row=0,sticky=N,pady=10)
    Label(login_screen, text="Username", font=("calibri,12")).grid(row=1,sticky=W)
    Label(login_screen, text="Password", font=("calibri,12")).grid(row=2,sticky=W)
    login_notif = Label(login_screen, font=("Calibri",12))
    login_notif.grid(row=4,sticky=N)
    #Entry
    Entry(login_screen, textvariable=temp_login_name).grid(row=1,column=1,padx=5)
    Entry(login_screen, textvariable=temp_login_password, show=("*")).grid(row=2,column=1,padx=5)
     
    #Buttons
    Button(login_screen, text="Login",command=login_session, width=15,font=("Calibri",12)).grid(row=3,sticky=W,pady=5,padx=5)
    
#Image import
img = Image.open(r'E:\bankimage.png.jpg')
img = img.resize((150,150))
img = ImageTk.PhotoImage(img)

#labels
Label(master, text="Custom Banking Beta", font=('Calibri', 14)).grid(row=0, sticky=N, pady=10)
Label(master, text="The most secure bank you 've probaly used" , font=('calibri', 12)).grid(row=1,sticky=N)
Label(master, image=img).grid(row=2, sticky=N, pady=15)

#button
Button(master, text="Register", font=('calibri',12),width=20,command=register).grid(row=3,sticky=N)
Button(master, text="Login", font=('calibri',12),width=20,command=login).grid(row=4,sticky=N,pady=5)
Button(master, text="Change Theme", font=('Calibri',12),width=20,command=change_theme).grid(row=6,sticky=N)

#-----------------------------------------------------------------------------------------------------------------------

conversion_table = {
    "USD": {
        "EUR": 0.85,
        "GBP": 0.72,
        "JPY": 109.71,
        "CAD": 1.22,
        "AUD": 1.32
    },
    "EUR": {
        "USD": 1.18,
        "GBP": 0.85,
        "JPY": 129.67,
        "CAD": 1.47,
        "AUD": 1.59
    },
    "GBP": {
        "USD": 1.39,
        "EUR": 1.18,
        "JPY": 151.37,
        "CAD": 1.70,
        "AUD": 1.84
    },
    "JPY": {
        "USD": 0.0091,
        "EUR": 0.0077,
        "GBP": 0.0066,
        "CAD": 0.011,
        "AUD": 0.012
    },
    "CAD": {
        "USD": 0.82,
        "EUR": 0.68,
        "GBP": 0.59,
        "JPY": 87.47,
        "AUD": 1.08
    },
    "AUD": {
        "USD": 0.76,
        "EUR": 0.63,
        "GBP": 0.54,
        "JPY": 81.75,
        "CAD": 0.93
    }
}

def convert_currency():
    amount = float(entry.get())
    base_currency = base_currency_var.get()
    target_currency = target_currency_var.get()

    if base_currency == target_currency:
        converted_amount = amount
    else:
        conversion_rate = conversion_table[base_currency][target_currency]
        converted_amount = amount * conversion_rate

    result_label.config(text=str(converted_amount))
###################################################################################################################
def currancy_screen():
    window = Toplevel(begin)
    window.title("Currency Converter")

    label1 = tk.Label(window, text="Amount:")
    label1.pack()

    entry = tk.Entry(window)
    entry.pack()

    label2 = tk.Label(window, text="Base Currency:")
    label2.pack()

    base_currency_var = tk.StringVar()
    base_currency_var.set("USD")

    base_currency_menu=tk.OptionMenu(window,base_currency_var,*conversion_table.keys())
    base_currency_menu.pack()

    label3 = tk.Label(window, text="Target Currency:")
    label3.pack()

    target_currency_var = tk.StringVar()
    target_currency_var.set("EUR")

    target_currency_menu=tk.OptionMenu(window,target_currency_var,*conversion_table.keys())
    target_currency_menu.pack()

    label4 = tk.Label(window, text="Converted Amount:")
    label4.pack()

    result_label = tk.Label(window, text="")
    result_label.pack()

    button = tk.Button(window, text="Convert", command=convert_currency)
    button.pack()


#labels
Label(begin, text="your money is safe", font=('Calibri', 14)).grid(row=0, sticky=N, pady=10)
Label(begin, text="The most secure bank in the world" , font=('Calibri', 12)).grid(row=1,sticky=N)
Label(begin).grid(row=2, sticky=N, pady=15)

#button
Button(begin, text="Employee", font=('Calibri',12),width=20,command=login).grid(row=3,sticky=N)
Button(begin, text="Customer", font=('Calibri',12),width=20,command=register).grid(row=4,sticky=N,pady=5)

begin.mainloop()
